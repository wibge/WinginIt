from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch


class CoopBot:
    prime_hub = PrimeHub(top_side=Axis.Z, front_side=Axis.X)
    left_sensor = ColorSensor(Port.F)
    right_sensor = ColorSensor(Port.D)
    top_motor = Motor(Port.A, Direction.CLOCKWISE)
    front_motor = Motor(Port.C, Direction.CLOCKWISE)
    left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E, Direction.CLOCKWISE)
    drive_base = DriveBase(left_motor, right_motor, 56, 94)

bot = CoopBot()