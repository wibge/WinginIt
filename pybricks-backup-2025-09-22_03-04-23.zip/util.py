from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from CoopBot import bot

def main():
    #bot.front_motor.run_until_stalled(100, Stop.COAST, 50)
    print("Wingin' it")
    #bot.driveStraight(1001)
    print(left_sensor.hsv())
    print(right_sensor.hsv())
    print(left_sensor.reflection())
    print(right_sensor.reflection())
    print('Hello, Pybricks!')
    bot.colorCode(1000,100)
    





main()
