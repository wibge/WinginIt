from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.parameters import Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

LEFT = 1
RIGHT = 0

BLACK = 1
WHITE = 0


class CoopBot:
    prime_hub = PrimeHub(top_side=Axis.Z, front_side=Axis.X)
    left_sensor = ColorSensor(Port.D)
    right_sensor = ColorSensor(Port.F)
    top_motor = Motor(Port.A, Direction.CLOCKWISE)
    front_motor = Motor(Port.C, Direction.CLOCKWISE)
    left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E, Direction.CLOCKWISE)
    drive_base = DriveBase(left_motor, right_motor, 56, 94)

    def driveStraight(self, distance, speed=100):
        direction = 1 if distance > 0 else -1
        speed = speed * direction
        self.drive_base.reset()
        self.prime_hub.imu.reset_heading()
        wait(10)
        self.drive_base.drive(speed, 0)
        
        print("Start: " + str(self.prime_hub.imu.heading()) + " " + str(self.drive_base.distance()))
        while self.drive_base.distance() * direction <= (distance * direction):
            print(str(self.prime_hub.imu.heading()) + " " + str(self.drive_base.distance()))
            heading = self.prime_hub.imu.heading()
            self.drive_base.drive(speed, -heading)
        self.drive_base.stop()

    def isSensorOnColor(self, side, color=BLACK):
        black_cutoff = 6
        white_cutoff = 20
        if color == BLACK:
            if side == LEFT:
                return self.left_sensor.reflection() < black_cutoff
            else: 
                return self.right_sensor.reflection() < black_cutoff
        else: 
            if side == LEFT:
                return self.left_sensor.reflection() > white_cutoff
            else: 
                return self.right_sensor.reflection() < white_cutoff

    def colorCode(self, speed=100):
        self.drive_base.reset()
        self.drive_base.settings(straight_speed=speed)
        self.drive_base.drive(speed, 0)
    
        while self.isSensorOnColor(LEFT, BLACK):
            print(self.left_sensor.hsv())
            print(self.right_sensor.hsv())
            print(self.left_sensor.reflection())
            print(self.right_sensor.reflection())
            print(str(self.prime_hub.imu.heading()) + " " + str(self.drive_base.distance()))
            heading = self.prime_hub.imu.heading()
            self.drive_base.drive(speed, -heading)
        self.drive_base.stop()
            
    def colorPrint(self):
                print("Left: " + str(self.left_sensor.reflection()) + " " + str(self.left_sensor.hsv()))
                print("Rght: " + str(self.right_sensor.reflection()) + " " + str(self.right_sensor.hsv()))

bot = CoopBot()

def main():
    #bot.front_motor.run_until_stalled(100, Stop.COAST, 50)
    print("Wingin' it")
    bot.driveStraight(-500)
    bot.colorCode()
  
    bot.colorPrint()



main()
