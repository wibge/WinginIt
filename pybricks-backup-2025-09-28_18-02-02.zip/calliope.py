
def addNumbers(number1, number2):
    return number1 + number2



x = addNumbers(2, 4)
print(x)